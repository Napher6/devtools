#' @param pkg The package to use, can be a file path to the package or a
#'   package object.  See [as.package()] for more information.
